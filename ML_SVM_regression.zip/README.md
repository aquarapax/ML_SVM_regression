# Домашнее задание по теме  
## «Регрессия SVM»

Решение в svm_regression_note.ipynb